---
name: ralph-wiggum-loop
description: Implement iterative self-referential development loops in Cursor. The agent repeatedly works on a task, validates results, and self-corrects until completion criteria are met. Use when the user asks for ralph loop, iterative development, autonomous iteration, self-correcting implementation, or continuous refinement until tests pass.
---

# Ralph Wiggum Loop for Cursor

Adapted from the [Ralph Wiggum technique](https://ghuntley.com/ralph/) for Claude Code. Ralph is an iterative, self-referential AI development loop: the agent works on a task, checks its own output, and repeats until the task is genuinely complete.

## Core Concept

Instead of attempting a perfect one-shot implementation, Ralph embraces **iteration**:

```
Prompt → Work → Validate → Not done? → Same prompt → Work again → ...
```

The agent reads its own previous work (files, git history, test output) each iteration, building on what exists rather than starting fresh.

## When to Use

**Good for:**
- Tasks with automatic verification (tests, linters, type checks)
- Multi-step implementations requiring iteration and refinement
- Greenfield features with clear completion criteria
- Bug fixes where the root cause is unclear

**Not good for:**
- Tasks requiring human judgment or design decisions
- One-shot operations (file rename, simple config change)
- Tasks with unclear success criteria

## How It Works in Cursor

Since Cursor does not have stop hooks, the loop is implemented as a **self-managed iteration pattern** within a single agent session.

### Step 1: Parse the User's Request

Extract from the user's message:
- **Task description**: What to build or fix
- **Completion criteria**: How to verify success (tests, linter, build, manual check)
- **Max iterations**: Safety limit (default: 10 if not specified)

### Step 2: Initialize Loop State

Create a todo list to track iteration progress:

```
Ralph Loop Progress:
- Iteration 1 of N [in_progress]
- Validate results [pending]
- Iterate if needed [pending]
```

### Step 3: Execute Iteration Loop

For each iteration:

1. **Assess current state**
   - Read relevant files to see previous work
   - Check git diff for recent changes
   - Review any existing test results or error output

2. **Work on the task**
   - Implement or improve based on current state
   - Make incremental progress, not wholesale rewrites
   - Each iteration should build on the last

3. **Validate**
   - Run the verification command (test suite, build, linter)
   - Capture full output for analysis

4. **Decide: continue or complete**
   - All criteria met → **COMPLETE** - report success
   - Criteria not met → analyze failures, plan fixes, start next iteration
   - Max iterations reached → **STOP** - report what was achieved and what remains

### Step 4: Report Results

On completion or max iterations, provide:
- Total iterations used
- What was accomplished
- Any remaining issues (if stopped early)

## Test Integrity Rules (CRITICAL)

The purpose of Ralph loop is to fix **implementation**, NOT to game tests into passing.
Violating these rules makes the entire loop worthless.

### ABSOLUTE PROHIBITIONS

These are **never acceptable**, even to make tests pass:

1. **No type cheating**
   - NEVER use `as any`, `as unknown as X`, `@ts-ignore`, `@ts-expect-error`
   - NEVER widen a type just to suppress errors (e.g. `string | any`)
   - NEVER cast to bypass type checks

2. **No mock manipulation**
   - NEVER change mock return values to match what the test expects without verifying the real implementation returns the same
   - NEVER add `mockResolvedValue(expected)` where `expected` is copied from the assertion
   - Mock data must reflect **realistic production behavior**, not test expectations
   - If mock data needs updating, the change must match a real implementation change

3. **No test weakening**
   - NEVER delete or skip (`xit`, `xdescribe`, `.skip`) a failing test
   - NEVER relax assertions (e.g. `toEqual` → `toBeTruthy`, specific value → `expect.anything()`)
   - NEVER remove edge case tests because they're "hard to fix"
   - NEVER change expected values to match wrong output

4. **No silent suppression**
   - NEVER wrap code in `try/catch` that swallows errors just to pass
   - NEVER add `optional chaining (?.)` everywhere to avoid null errors without understanding why null occurs
   - NEVER return empty/default values to bypass logic

### The Golden Rule

> **Fix direction: Implementation → passes test. NOT: Test → matches implementation.**

When a test fails, ask: "Is the test wrong or is the implementation wrong?"

- **Test is wrong** (rare): The test has an outdated expectation due to a legitimate requirement change. Update the test AND document why in the commit message.
- **Implementation is wrong** (common): The code doesn't behave as specified. Fix the implementation.

### Mock Data Quality Checklist

Before writing or modifying any mock:

- [ ] Does this mock reflect a realistic production scenario?
- [ ] Would this data actually exist in the real database/API?
- [ ] Are field values realistic (not `"test"`, `"abc"`, `123` placeholders)?
- [ ] Do relationships between entities make logical sense?
- [ ] Are edge cases (null, empty, boundary values) represented where relevant?

### When You're Stuck

If the same test keeps failing after 3 attempts:

1. **STOP** - do not force a fix
2. Read the test carefully to understand the **intent** (what behavior is being verified?)
3. Read the implementation the test targets
4. Trace the data flow from input to assertion
5. If the test truly seems wrong, explain why and ask the user before changing it

## Iteration Rules

### DO
- Read your own previous output before each iteration
- Make incremental, targeted fixes based on validation feedback
- Track what you've tried to avoid repeating failed approaches
- Use git commits between iterations to preserve progress
- Fix the **implementation** to satisfy the test, not the other way around

### DO NOT
- Rewrite everything from scratch each iteration
- Ignore test output or error messages
- Skip validation to "save time"
- Exceed max iterations without reporting
- Change test assertions to match broken implementation
- Use type escape hatches (`any`, `as`, `@ts-ignore`)

## Validation Commands

Use the appropriate verification for the project:

| Project Type | Command | Success Signal |
|---|---|---|
| NestJS/Node | `npm test` or `npm run test` | All tests pass |
| TypeScript | `npx tsc --noEmit` | No type errors |
| Linting | `npm run lint` | No lint errors |
| Build | `npm run build` | Build succeeds |
| Custom | User-specified | User-specified |

Chain multiple validators when appropriate:
```bash
npm run lint && npx tsc --noEmit && npm test
```

## Prompt Template

When starting a Ralph loop, structure the work as:

```
RALPH LOOP - Iteration {N}/{MAX}

TASK: {original task description}

COMPLETION CRITERIA:
- {criterion 1}
- {criterion 2}

INTEGRITY CHECK (every iteration):
- [ ] No `any`, `as any`, `@ts-ignore` introduced
- [ ] No mock data copy-pasted from assertions
- [ ] No tests deleted, skipped, or weakened
- [ ] All fixes are in implementation, not in tests

PREVIOUS STATE:
- {what was done in prior iterations}
- {what failed and why}

THIS ITERATION PLAN:
- {specific targeted fix or improvement}
```

## Self-Correction Strategy

When validation fails:

1. **Read the full error output** - don't guess
2. **Identify the root cause** - not just the symptom
3. **Check if this error was seen before** - avoid loops on the same fix
4. **Try a different approach** if the same fix failed twice
5. **Document what you tried** in todo updates

## Safety Mechanisms

- **Max iterations**: Always enforce a limit (default: 10)
- **Diminishing returns detection**: If 3 consecutive iterations make no progress, stop and report
- **Scope guard**: Don't expand scope beyond the original task
- **Commit checkpoints**: Git commit working states so progress isn't lost

## Example Usage

User: "Make all tests pass using ralph loop approach"

### CORRECT agent behavior:
```
Iteration 1/10:
  → Run tests → 15 failures
  → Read failing tests to understand INTENT
  → Root cause: service method signature changed, implementation doesn't match
  → Fix: update service implementation to return correct shape
  → Integrity ✓: no type cheats, no mock manipulation
  → Commit: "fix: align service return type with domain contract"

Iteration 2/10:
  → Run tests → 8 failures
  → Root cause: repository method not handling null case
  → Fix: add null guard in repository implementation
  → Integrity ✓: used proper Optional pattern, not `?.` everywhere
  → Commit: "fix: handle null entity in repository lookup"

Iteration 3/10:
  → Run tests → 2 failures
  → Root cause: event handler not awaiting async operation
  → Fix: add await, update handler to properly chain promises
  → Integrity ✓: no try/catch swallowing
  → Commit: "fix: await async event dispatch in handler"

Iteration 4/10:
  → Run tests → 0 failures ✅
  → COMPLETE. Report: "All tests passing after 4 iterations"
```

### WRONG agent behavior (violates integrity):
```
❌ Iteration 1: test expects { id: 1, name: "foo" }
   → Agent changes mock to return { id: 1, name: "foo" }     ← COPYING ASSERTION
   
❌ Iteration 2: type error on service method
   → Agent adds `as any` to suppress                          ← TYPE CHEATING

❌ Iteration 3: edge case test keeps failing
   → Agent adds `.skip` to the test                           ← TEST WEAKENING

❌ Iteration 4: 0 failures
   → "COMPLETE" ← This is FAKE completion. Tests are meaningless now.
```

## Additional Resources

- For prompt writing best practices, see [prompt-examples.md](prompt-examples.md)
- Original technique: https://ghuntley.com/ralph/
- Claude Code plugin: https://github.com/anthropics/claude-code/tree/main/plugins/ralph-wiggum
