# React Best Practices - Detailed Rules

**Version 1.0.0** - Vercel Engineering

This document contains detailed explanations and full code examples for all 57 performance optimization rules.

---

## 1. Eliminating Waterfalls

**Impact: CRITICAL** - Waterfalls are the #1 performance killer. Each sequential await adds full network latency.

### 1.1 Defer Await Until Needed

Move `await` operations into the branches where they're actually used.

**Incorrect:**
```typescript
async function handleRequest(userId: string, skipProcessing: boolean) {
  const userData = await fetchUserData(userId) // Blocks both branches
  
  if (skipProcessing) {
    return { skipped: true }
  }
  return processUserData(userData)
}
```

**Correct:**
```typescript
async function handleRequest(userId: string, skipProcessing: boolean) {
  if (skipProcessing) {
    return { skipped: true }
  }
  const userData = await fetchUserData(userId)
  return processUserData(userData)
}
```

### 1.2 Dependency-Based Parallelization

Use `better-all` for operations with partial dependencies.

**Incorrect:**
```typescript
const [user, config] = await Promise.all([fetchUser(), fetchConfig()])
const profile = await fetchProfile(user.id) // Waits for config unnecessarily
```

**Correct:**
```typescript
import { all } from 'better-all'

const { user, config, profile } = await all({
  async user() { return fetchUser() },
  async config() { return fetchConfig() },
  async profile() { return fetchProfile((await this.$.user).id) }
})
```

### 1.3 Promise.all() for Independent Operations

**Incorrect:**
```typescript
const user = await fetchUser()
const posts = await fetchPosts()
const comments = await fetchComments()
```

**Correct:**
```typescript
const [user, posts, comments] = await Promise.all([
  fetchUser(),
  fetchPosts(),
  fetchComments()
])
```

### 1.4 Prevent Waterfall Chains in API Routes

Start independent operations immediately, await later.

**Incorrect:**
```typescript
export async function GET(request: Request) {
  const session = await auth()
  const config = await fetchConfig()
  const data = await fetchData(session.user.id)
  return Response.json({ data, config })
}
```

**Correct:**
```typescript
export async function GET(request: Request) {
  const sessionPromise = auth()
  const configPromise = fetchConfig()
  const session = await sessionPromise
  const [config, data] = await Promise.all([
    configPromise,
    fetchData(session.user.id)
  ])
  return Response.json({ data, config })
}
```

### 1.5 Strategic Suspense Boundaries

Use Suspense to show wrapper UI faster while data loads.

**Incorrect:**
```tsx
async function Page() {
  const data = await fetchData() // Blocks entire page
  return (
    <div>
      <Sidebar />
      <DataDisplay data={data} />
      <Footer />
    </div>
  )
}
```

**Correct:**
```tsx
function Page() {
  return (
    <div>
      <Sidebar />
      <Suspense fallback={<Skeleton />}>
        <DataDisplay />
      </Suspense>
      <Footer />
    </div>
  )
}

async function DataDisplay() {
  const data = await fetchData()
  return <div>{data.content}</div>
}
```

---

## 2. Bundle Size Optimization

**Impact: CRITICAL** - Reducing bundle size improves TTI and LCP.

### 2.1 Avoid Barrel File Imports

Import directly from source files.

**Incorrect:**
```tsx
import { Check, X, Menu } from 'lucide-react' // Loads 1,583 modules
import { Button, TextField } from '@mui/material' // Loads 2,225 modules
```

**Correct:**
```tsx
import Check from 'lucide-react/dist/esm/icons/check'
import X from 'lucide-react/dist/esm/icons/x'
import Button from '@mui/material/Button'
```

**Next.js 13.5+ alternative:**
```js
// next.config.js
module.exports = {
  experimental: {
    optimizePackageImports: ['lucide-react', '@mui/material']
  }
}
```

### 2.2 Dynamic Imports for Heavy Components

**Incorrect:**
```tsx
import { MonacoEditor } from './monaco-editor' // ~300KB in main chunk
```

**Correct:**
```tsx
import dynamic from 'next/dynamic'

const MonacoEditor = dynamic(
  () => import('./monaco-editor').then(m => m.MonacoEditor),
  { ssr: false }
)
```

### 2.3 Defer Non-Critical Libraries

**Incorrect:**
```tsx
import { Analytics } from '@vercel/analytics/react'
```

**Correct:**
```tsx
import dynamic from 'next/dynamic'

const Analytics = dynamic(
  () => import('@vercel/analytics/react').then(m => m.Analytics),
  { ssr: false }
)
```

### 2.4 Preload Based on User Intent

```tsx
function EditorButton({ onClick }: { onClick: () => void }) {
  const preload = () => {
    if (typeof window !== 'undefined') {
      void import('./monaco-editor')
    }
  }

  return (
    <button onMouseEnter={preload} onFocus={preload} onClick={onClick}>
      Open Editor
    </button>
  )
}
```

---

## 3. Server-Side Performance

**Impact: HIGH**

### 3.1 Authenticate Server Actions

Server Actions are public endpoints. Always verify auth inside each action.

**Incorrect:**
```typescript
'use server'
export async function deleteUser(userId: string) {
  await db.user.delete({ where: { id: userId } })
}
```

**Correct:**
```typescript
'use server'
import { verifySession } from '@/lib/auth'

export async function deleteUser(userId: string) {
  const session = await verifySession()
  if (!session) throw new Error('Unauthorized')
  if (session.user.role !== 'admin' && session.user.id !== userId) {
    throw new Error('Forbidden')
  }
  await db.user.delete({ where: { id: userId } })
}
```

### 3.2 Per-Request Deduplication with React.cache()

```typescript
import { cache } from 'react'

export const getCurrentUser = cache(async () => {
  const session = await auth()
  if (!session?.user?.id) return null
  return await db.user.findUnique({ where: { id: session.user.id } })
})
```

### 3.3 Cross-Request LRU Caching

```typescript
import { LRUCache } from 'lru-cache'

const cache = new LRUCache<string, any>({
  max: 1000,
  ttl: 5 * 60 * 1000
})

export async function getUser(id: string) {
  const cached = cache.get(id)
  if (cached) return cached
  const user = await db.user.findUnique({ where: { id } })
  cache.set(id, user)
  return user
}
```

### 3.4 Minimize Serialization at RSC Boundaries

**Incorrect:**
```tsx
async function Page() {
  const user = await fetchUser() // 50 fields
  return <Profile user={user} /> // Client uses 1 field
}
```

**Correct:**
```tsx
async function Page() {
  const user = await fetchUser()
  return <Profile name={user.name} />
}
```

### 3.5 Use after() for Non-Blocking Operations

```tsx
import { after } from 'next/server'

export async function POST(request: Request) {
  await updateDatabase(request)
  
  after(async () => {
    const userAgent = (await headers()).get('user-agent')
    logUserAction({ userAgent })
  })
  
  return Response.json({ status: 'success' })
}
```

---

## 4. Client-Side Data Fetching

**Impact: MEDIUM-HIGH**

### 4.1 Use SWR for Automatic Deduplication

**Incorrect:**
```tsx
function UserList() {
  const [users, setUsers] = useState([])
  useEffect(() => {
    fetch('/api/users').then(r => r.json()).then(setUsers)
  }, [])
}
```

**Correct:**
```tsx
import useSWR from 'swr'

function UserList() {
  const { data: users } = useSWR('/api/users', fetcher)
}
```

### 4.2 Use Passive Event Listeners

```typescript
useEffect(() => {
  const handleWheel = (e: WheelEvent) => console.log(e.deltaY)
  document.addEventListener('wheel', handleWheel, { passive: true })
  return () => document.removeEventListener('wheel', handleWheel)
}, [])
```

### 4.3 Version localStorage Data

```typescript
const VERSION = 'v2'

function saveConfig(config: Config) {
  try {
    localStorage.setItem(`userConfig:${VERSION}`, JSON.stringify(config))
  } catch {}
}
```

---

## 5. Re-render Optimization

**Impact: MEDIUM**

### 5.1 Calculate Derived State During Rendering

**Incorrect:**
```tsx
const [firstName, setFirstName] = useState('First')
const [fullName, setFullName] = useState('')

useEffect(() => {
  setFullName(firstName + ' ' + lastName)
}, [firstName, lastName])
```

**Correct:**
```tsx
const [firstName, setFirstName] = useState('First')
const fullName = firstName + ' ' + lastName
```

### 5.2 Use Functional setState Updates

**Incorrect:**
```tsx
const addItem = useCallback((item) => {
  setItems([...items, item])
}, [items]) // Recreated on every items change
```

**Correct:**
```tsx
const addItem = useCallback((item) => {
  setItems(curr => [...curr, item])
}, []) // Stable callback
```

### 5.3 Use Lazy State Initialization

**Incorrect:**
```tsx
const [settings, setSettings] = useState(
  JSON.parse(localStorage.getItem('settings') || '{}') // Runs every render
)
```

**Correct:**
```tsx
const [settings, setSettings] = useState(() => {
  const stored = localStorage.getItem('settings')
  return stored ? JSON.parse(stored) : {}
})
```

### 5.4 Extract Default Values from Memoized Components

**Incorrect:**
```tsx
const UserAvatar = memo(function UserAvatar({ onClick = () => {} }) {
  // Broken memoization - new function every render
})
```

**Correct:**
```tsx
const NOOP = () => {}
const UserAvatar = memo(function UserAvatar({ onClick = NOOP }) {
  // Memoization works
})
```

### 5.5 Narrow Effect Dependencies

**Incorrect:**
```tsx
useEffect(() => {
  console.log(user.id)
}, [user]) // Re-runs on any user field change
```

**Correct:**
```tsx
useEffect(() => {
  console.log(user.id)
}, [user.id]) // Re-runs only when id changes
```

### 5.6 Subscribe to Derived State

**Incorrect:**
```tsx
const width = useWindowWidth() // Updates continuously
const isMobile = width < 768
```

**Correct:**
```tsx
const isMobile = useMediaQuery('(max-width: 767px)') // Updates on breakpoint
```

### 5.7 Use Transitions for Non-Urgent Updates

```tsx
import { startTransition } from 'react'

useEffect(() => {
  const handler = () => {
    startTransition(() => setScrollY(window.scrollY))
  }
  window.addEventListener('scroll', handler, { passive: true })
  return () => window.removeEventListener('scroll', handler)
}, [])
```

---

## 6. Rendering Performance

**Impact: MEDIUM**

### 6.1 Use Explicit Conditional Rendering

**Incorrect:**
```tsx
{count && <Badge>{count}</Badge>} // Renders "0" when count is 0
```

**Correct:**
```tsx
{count > 0 ? <Badge>{count}</Badge> : null}
```

### 6.2 CSS content-visibility for Long Lists

```css
.message-item {
  content-visibility: auto;
  contain-intrinsic-size: 0 80px;
}
```

### 6.3 Hoist Static JSX Elements

**Incorrect:**
```tsx
function Container() {
  return loading && <div className="skeleton" /> // Recreates every render
}
```

**Correct:**
```tsx
const skeleton = <div className="skeleton" />

function Container() {
  return loading && skeleton
}
```

### 6.4 Animate SVG Wrapper

**Incorrect:**
```tsx
<svg className="animate-spin">...</svg> // No hardware acceleration
```

**Correct:**
```tsx
<div className="animate-spin">
  <svg>...</svg>
</div>
```

### 6.5 Prevent Hydration Mismatch Without Flickering

```tsx
function ThemeWrapper({ children }) {
  return (
    <>
      <div id="theme-wrapper">{children}</div>
      <script dangerouslySetInnerHTML={{
        __html: `(function() {
          var theme = localStorage.getItem('theme') || 'light';
          document.getElementById('theme-wrapper').className = theme;
        })();`
      }} />
    </>
  )
}
```

---

## 7. JavaScript Performance

**Impact: LOW-MEDIUM**

### 7.1 Build Index Maps for Repeated Lookups

**Incorrect:**
```typescript
orders.map(order => ({
  ...order,
  user: users.find(u => u.id === order.userId) // O(n) per lookup
}))
```

**Correct:**
```typescript
const userById = new Map(users.map(u => [u.id, u]))
orders.map(order => ({
  ...order,
  user: userById.get(order.userId) // O(1) per lookup
}))
```

### 7.2 Use Set/Map for O(1) Lookups

**Incorrect:**
```typescript
items.filter(item => allowedIds.includes(item.id)) // O(n) per check
```

**Correct:**
```typescript
const allowedIds = new Set(['a', 'b', 'c'])
items.filter(item => allowedIds.has(item.id)) // O(1) per check
```

### 7.3 Use toSorted() for Immutability

**Incorrect:**
```typescript
const sorted = users.sort((a, b) => a.name.localeCompare(b.name)) // Mutates
```

**Correct:**
```typescript
const sorted = users.toSorted((a, b) => a.name.localeCompare(b.name))
```

### 7.4 Combine Multiple Array Iterations

**Incorrect:**
```typescript
const admins = users.filter(u => u.isAdmin)
const inactive = users.filter(u => !u.isActive) // 2 iterations
```

**Correct:**
```typescript
const admins: User[] = []
const inactive: User[] = []
for (const user of users) {
  if (user.isAdmin) admins.push(user)
  if (!user.isActive) inactive.push(user)
} // 1 iteration
```

### 7.5 Early Length Check for Array Comparisons

```typescript
function hasChanges(current: string[], original: string[]) {
  if (current.length !== original.length) return true
  // Only compare when lengths match
}
```

### 7.6 Avoid Layout Thrashing

**Incorrect:**
```typescript
element.style.width = '100px'
const width = element.offsetWidth // Forces reflow
element.style.height = '200px'
```

**Correct:**
```typescript
element.style.width = '100px'
element.style.height = '200px'
const { width, height } = element.getBoundingClientRect() // Single reflow
```

---

## 8. Advanced Patterns

**Impact: LOW**

### 8.1 Initialize App Once, Not Per Mount

**Incorrect:**
```tsx
useEffect(() => {
  loadFromStorage()
  checkAuthToken()
}, []) // Runs twice in dev, re-runs on remount
```

**Correct:**
```tsx
let didInit = false

function App() {
  useEffect(() => {
    if (didInit) return
    didInit = true
    loadFromStorage()
    checkAuthToken()
  }, [])
}
```

### 8.2 useEffectEvent for Stable Callback Refs

```tsx
import { useEffectEvent } from 'react'

function SearchInput({ onSearch }) {
  const [query, setQuery] = useState('')
  const onSearchEvent = useEffectEvent(onSearch)

  useEffect(() => {
    const timeout = setTimeout(() => onSearchEvent(query), 300)
    return () => clearTimeout(timeout)
  }, [query]) // No onSearch dependency needed
}
```

---

## References

1. https://react.dev
2. https://nextjs.org
3. https://swr.vercel.app
4. https://github.com/shuding/better-all
5. https://github.com/isaacs/node-lru-cache
6. https://vercel.com/blog/how-we-optimized-package-imports-in-next-js
7. https://vercel.com/blog/how-we-made-the-vercel-dashboard-twice-as-fast
