---
name: nestjs-context-business-structure
description: NestJS 프로젝트에서 Context와 Business 레이어 구조를 생성한다. CQRS 패턴 기반 핸들러, 서비스, 모듈, 인터페이스를 포함한 전체 구조를 만들어준다. Context 생성, Business 모듈 생성, CQRS 핸들러 작성 시 사용한다.
---

# NestJS Context & Business 레이어 구조 생성

NestJS 백엔드에서 Context(도메인 로직)와 Business(오케스트레이션) 레이어를 CQRS 패턴에 따라 생성하는 스킬이다.

## 아키텍처 개요

```
src/
├── context/                           # 도메인 로직 레이어
│   ├── domain-context.module.ts       # 모든 Context 통합 모듈
│   └── {feature}-context/             # 개별 Context
│       ├── {feature}-context.module.ts
│       ├── {feature}.service.ts       # Context 서비스 (퍼사드)
│       ├── handlers/                  # CQRS 핸들러
│       │   └── {sub-feature}/
│       │       ├── commands/          # 쓰기 작업
│       │       ├── queries/           # 읽기 작업
│       │       └── index.ts
│       ├── interfaces/                # Command/Query 인터페이스
│       └── services/                  # 유틸리티 서비스 (선택)
│
├── business/                          # 오케스트레이션 레이어
│   ├── business.module.ts             # 모든 Business 통합 모듈
│   └── {feature}/
│       ├── {feature}-business.module.ts
│       └── {feature}-business.service.ts
```

## Context 레이어 생성

### 1. Context Module

```typescript
// {feature}-context/{feature}-context.module.ts
import { Module } from '@nestjs/common';
import { CqrsModule } from '@nestjs/cqrs';
import { TypeOrmModule } from '@nestjs/typeorm';
import { {Feature}ContextService } from './{feature}-context.service';
import { {FEATURE}_HANDLERS } from './handlers';
// 필요한 Entity, Repository import

@Module({
  imports: [
    CqrsModule,
    TypeOrmModule.forFeature([/* 필요한 Entity들 */]),
    // 의존하는 다른 Context 모듈
  ],
  providers: [
    {Feature}ContextService,
    ...{FEATURE}_HANDLERS,
  ],
  exports: [{Feature}ContextService],
})
export class {Feature}ContextModule {}
```

### 2. Context Service (퍼사드 패턴)

Context Service는 Handler를 직접 호출하거나 CommandBus/QueryBus를 사용한다.

```typescript
// {feature}-context/{feature}-context.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
// 또는 Handler 직접 주입
import { Create{Feature}Handler } from './handlers/{sub-feature}/commands/create-{feature}.handler';
import { Get{Feature}ListHandler } from './handlers/{sub-feature}/queries/get-{feature}-list.handler';

@Injectable()
export class {Feature}ContextService {
  private readonly logger = new Logger({Feature}ContextService.name);

  constructor(
    private readonly commandBus: CommandBus,
    private readonly queryBus: QueryBus,
    // 또는 직접 Handler 주입
    private readonly create{Feature}Handler: Create{Feature}Handler,
    private readonly get{Feature}ListHandler: Get{Feature}ListHandler,
  ) {}

  /**
   * 기능을 생성한다 (한글 메서드명 사용)
   */
  async 기능을_생성한다(data: Create{Feature}Dto): Promise<{Feature}Result> {
    this.logger.log('기능 생성 시작', { data });
    
    const command = new Create{Feature}Command(data);
    return this.commandBus.execute(command);
    // 또는: return this.create{Feature}Handler.execute(command);
  }

  /**
   * 기능 목록을 조회한다
   */
  async 기능_목록을_조회한다(filter: {Feature}Filter): Promise<{Feature}ListResult> {
    const query = new Get{Feature}ListQuery(filter);
    return this.queryBus.execute(query);
  }
}
```

### 3. Handler 구조

#### Command Handler (쓰기 작업)

```typescript
// handlers/{sub-feature}/commands/create-{feature}.handler.ts
import { Injectable, Logger } from '@nestjs/common';
import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

export class Create{Feature}Command {
  constructor(
    public readonly data: Create{Feature}Dto,
    public readonly createdBy: string,
  ) {}
}

@Injectable()
@CommandHandler(Create{Feature}Command)
export class Create{Feature}Handler
  implements ICommandHandler<Create{Feature}Command, string>
{
  private readonly logger = new Logger(Create{Feature}Handler.name);

  constructor(
    @InjectRepository({Feature}Entity)
    private readonly repository: Repository<{Feature}Entity>,
  ) {}

  async execute(command: Create{Feature}Command): Promise<string> {
    const { data, createdBy } = command;
    
    this.logger.log('생성 시작', { data });

    // 비즈니스 로직 구현
    const entity = this.repository.create({
      ...data,
      createdBy,
    });

    const saved = await this.repository.save(entity);
    
    this.logger.log('생성 완료', { id: saved.id });
    return saved.id;
  }
}
```

#### Query Handler (읽기 작업)

```typescript
// handlers/{sub-feature}/queries/get-{feature}-list.handler.ts
import { Injectable, Logger } from '@nestjs/common';
import { QueryHandler, IQueryHandler } from '@nestjs/cqrs';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

export class Get{Feature}ListQuery {
  constructor(
    public readonly filter: {Feature}Filter,
  ) {}
}

export interface {Feature}ListResult {
  items: {Feature}Dto[];
  total: number;
}

@Injectable()
@QueryHandler(Get{Feature}ListQuery)
export class Get{Feature}ListHandler
  implements IQueryHandler<Get{Feature}ListQuery, {Feature}ListResult>
{
  private readonly logger = new Logger(Get{Feature}ListHandler.name);

  constructor(
    @InjectRepository({Feature}Entity)
    private readonly repository: Repository<{Feature}Entity>,
  ) {}

  async execute(query: Get{Feature}ListQuery): Promise<{Feature}ListResult> {
    const { filter } = query;
    
    // QueryBuilder 사용 시 deletedAt IS NULL 조건 필수
    const qb = this.repository
      .createQueryBuilder('entity')
      .where('entity.deletedAt IS NULL');

    if (filter.status) {
      qb.andWhere('entity.status = :status', { status: filter.status });
    }

    const [items, total] = await qb.getManyAndCount();
    
    return { items, total };
  }
}
```

### 4. Handler Index 파일

```typescript
// handlers/{sub-feature}/index.ts

// Commands
export {
  Create{Feature}Command,
  Create{Feature}Handler,
} from './commands/create-{feature}.handler';

export {
  Update{Feature}Command,
  Update{Feature}Handler,
} from './commands/update-{feature}.handler';

export {
  Delete{Feature}Command,
  Delete{Feature}Handler,
} from './commands/delete-{feature}.handler';

// Queries
export {
  Get{Feature}ListQuery,
  Get{Feature}ListHandler,
  type {Feature}ListResult,
} from './queries/get-{feature}-list.handler';

export {
  Get{Feature}DetailQuery,
  Get{Feature}DetailHandler,
} from './queries/get-{feature}-detail.handler';

// Handler 배열 (Module에서 사용)
import { Create{Feature}Handler } from './commands/create-{feature}.handler';
import { Update{Feature}Handler } from './commands/update-{feature}.handler';
import { Delete{Feature}Handler } from './commands/delete-{feature}.handler';
import { Get{Feature}ListHandler } from './queries/get-{feature}-list.handler';
import { Get{Feature}DetailHandler } from './queries/get-{feature}-detail.handler';

export const {FEATURE}_COMMAND_HANDLERS = [
  Create{Feature}Handler,
  Update{Feature}Handler,
  Delete{Feature}Handler,
];

export const {FEATURE}_QUERY_HANDLERS = [
  Get{Feature}ListHandler,
  Get{Feature}DetailHandler,
];

export const {FEATURE}_HANDLERS = [
  ...{FEATURE}_COMMAND_HANDLERS,
  ...{FEATURE}_QUERY_HANDLERS,
];
```

### 5. Interface 파일

```typescript
// interfaces/{feature}-context.interface.ts

/**
 * 기능 생성 커맨드
 */
export interface Create{Feature}CommandData {
  name: string;
  description?: string;
  // ...필요한 필드
}

/**
 * 기능 생성 결과
 */
export interface Create{Feature}Result {
  id: string;
  message: string;
}

/**
 * 기능 조회 필터
 */
export interface {Feature}Filter {
  status?: string;
  startDate?: Date;
  endDate?: Date;
}

/**
 * 기능 DTO
 */
export interface {Feature}Dto {
  id: string;
  name: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
}
```

## Business 레이어 생성

### 1. Business Module

```typescript
// {feature}/{feature}-business.module.ts
import { Module } from '@nestjs/common';
import { {Feature}ContextModule } from '@context/{feature}-context/{feature}-context.module';
import { AuditLogContextModule } from '@context/audit-log-context/audit-log-context.module';
import { {Feature}BusinessService } from './{feature}-business.service';

/**
 * {Feature} 비즈니스 모듈
 */
@Module({
  imports: [
    {Feature}ContextModule,
    AuditLogContextModule, // 활동 내역 기록용 (선택)
  ],
  providers: [{Feature}BusinessService],
  exports: [{Feature}BusinessService],
})
export class {Feature}BusinessModule {}
```

### 2. Business Service (오케스트레이션)

```typescript
// {feature}/{feature}-business.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { {Feature}ContextService } from '@context/{feature}-context/{feature}-context.service';
import { AuditLogContextService } from '@context/audit-log-context/audit-log-context.service';

/**
 * {Feature} 비즈니스 서비스
 *
 * {Feature} 관련 비즈니스 로직을 오케스트레이션한다.
 * - 핵심 도메인 로직 호출
 * - 활동 내역 자동 기록
 * - 여러 Context 조합
 */
@Injectable()
export class {Feature}BusinessService {
  private readonly logger = new Logger({Feature}BusinessService.name);

  constructor(
    private readonly {feature}ContextService: {Feature}ContextService,
    private readonly auditLogService: AuditLogContextService,
  ) {}

  /**
   * 기능을 생성한다 (활동 내역 기록 포함)
   */
  async 기능을_생성한다(
    data: Create{Feature}Dto,
    createdBy: string,
  ): Promise<Create{Feature}Result> {
    this.logger.log('기능 생성 시작', { data });

    // 1. 핵심 도메인 로직 실행
    const result = await this.{feature}ContextService.기능을_생성한다(data);

    // 2. 활동 내역 기록 (실패해도 메인 로직에 영향 없음)
    try {
      await this.auditLogService.활동내역을_기록한다({
        entityType: '{feature}',
        entityId: result.id,
        action: 'created',
        performedBy: createdBy,
        metadata: { ...data },
      });
    } catch (error) {
      this.logger.warn('활동 내역 기록 실패', {
        entityId: result.id,
        error: error.message,
      });
    }

    this.logger.log('기능 생성 완료', { id: result.id });
    return result;
  }

  /**
   * 기능 목록을 조회한다
   */
  async 기능_목록을_조회한다(filter: {Feature}Filter): Promise<{Feature}ListResult> {
    return this.{feature}ContextService.기능_목록을_조회한다(filter);
  }
}
```

## 통합 모듈 설정

### Domain Context Module

```typescript
// context/domain-context.module.ts
import { Module } from '@nestjs/common';
import { {Feature}ContextModule } from './{feature}-context/{feature}-context.module';
// ... 다른 Context 모듈 import

@Module({
  imports: [
    {Feature}ContextModule,
    // ... 다른 Context 모듈
  ],
  exports: [
    {Feature}ContextModule,
    // ... 다른 Context 모듈
  ],
})
export class DomainContextModule {}
```

### Business Module

```typescript
// business/business.module.ts
import { Module } from '@nestjs/common';
import { {Feature}BusinessModule } from './{feature}/{feature}-business.module';
// ... 다른 Business 모듈 import

/**
 * 비즈니스 레이어 통합 모듈
 *
 * 비즈니스 로직 오케스트레이션을 담당하는 모든 비즈니스 모듈을 통합한다.
 */
@Module({
  imports: [
    {Feature}BusinessModule,
    // ... 다른 Business 모듈
  ],
  exports: [
    {Feature}BusinessModule,
    // ... 다른 Business 모듈
  ],
})
export class BusinessModule {}
```

## 네이밍 컨벤션

### Context Service 메서드명 (한글)

```typescript
// ✅ 올바른 예시
async 기능을_생성한다(data: CreateDto)
async 기능을_수정한다(id: string, data: UpdateDto)
async 기능을_삭제한다(id: string)
async 기능_목록을_조회한다(filter: Filter)
async 기능_상세를_조회한다(id: string)

// ❌ 잘못된 예시
async createFeature(data: CreateDto)
async getFeatureList(filter: Filter)
```

### Handler 클래스명 (영문)

```typescript
// Command: 동사 + 기능명 + Command/Handler
Create{Feature}Command / Create{Feature}Handler
Update{Feature}Command / Update{Feature}Handler
Delete{Feature}Command / Delete{Feature}Handler
Cancel{Feature}Command / Cancel{Feature}Handler
Bulk{Action}{Feature}Command / Bulk{Action}{Feature}Handler

// Query: Get + 기능명 + Query/Handler
Get{Feature}ListQuery / Get{Feature}ListHandler
Get{Feature}DetailQuery / Get{Feature}DetailHandler
Get{Feature}ByIdQuery / Get{Feature}ByIdHandler
```

### 파일명

```
commands/
  create-{feature}.handler.ts
  update-{feature}.handler.ts
  delete-{feature}.handler.ts
  bulk-create-{feature}.handler.ts

queries/
  get-{feature}-list.handler.ts
  get-{feature}-detail.handler.ts
  get-{feature}-by-id.handler.ts
```

## QueryBuilder 체크리스트

쿼리 작성 시 반드시 확인:

- [ ] 메인 엔티티에 `deletedAt IS NULL` 조건 추가
- [ ] 모든 `leftJoin`에 조인 엔티티의 `deletedAt IS NULL` 조건 추가
- [ ] `getRawMany/getRawOne` 사용 시 명시적 `AS alias` 지정
- [ ] Date 타입 필드는 적절히 변환 (ISO 8601)

```typescript
// ✅ 올바른 QueryBuilder 예시
const result = await this.repository
  .createQueryBuilder('entity')
  .select([
    'entity.id AS entity_id',
    'entity.name AS entity_name',
    'related.name AS related_name',
  ])
  .leftJoin(
    Related,
    'related',
    'related.id = entity.relatedId AND related.deletedAt IS NULL',
  )
  .where('entity.deletedAt IS NULL')
  .andWhere('entity.status = :status', { status })
  .getRawMany();
```

## 생성 체크리스트

새 기능 생성 시:

1. **Context 레이어**
   - [ ] `{feature}-context.module.ts` 생성
   - [ ] `{feature}-context.service.ts` 생성
   - [ ] `handlers/{sub-feature}/commands/` 핸들러 생성
   - [ ] `handlers/{sub-feature}/queries/` 핸들러 생성
   - [ ] `handlers/{sub-feature}/index.ts` 생성
   - [ ] `interfaces/{feature}-context.interface.ts` 생성
   - [ ] `domain-context.module.ts`에 모듈 등록

2. **Business 레이어**
   - [ ] `{feature}-business.module.ts` 생성
   - [ ] `{feature}-business.service.ts` 생성
   - [ ] `business.module.ts`에 모듈 등록
