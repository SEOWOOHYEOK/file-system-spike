# Ralph Loop Prompt Examples

Best practices and examples for writing effective Ralph loop prompts.

## Principles

1. **Clear completion criteria** - The agent must know when to stop
2. **Incremental goals** - Break large tasks into verifiable phases
3. **Self-correction guidance** - Tell the agent how to handle failures
4. **Safety limits** - Always set max iterations

## Good Prompts

### Example 1: Make Tests Pass

```
Use ralph loop to make all tests pass.

Completion criteria:
- `npm test` exits with code 0
- No skipped tests

Max iterations: 15
```

Why it works: Clear verification command, measurable success, reasonable limit.

### Example 2: Fix Build Errors

```
Use ralph loop to fix all TypeScript build errors.

Completion criteria:
- `npx tsc --noEmit` produces zero errors
- No `@ts-ignore` or `any` type workarounds

Max iterations: 10
```

Why it works: Specific tool, explicit anti-patterns to avoid.

### Example 3: Phased Implementation

```
Use ralph loop to implement user authentication:

Phase 1: JWT token generation and validation (tests pass)
Phase 2: Login endpoint with input validation (tests pass)
Phase 3: Auth middleware protecting routes (tests pass)

Completion criteria:
- All phases implemented
- All tests passing
- No lint errors

Max iterations: 20
```

Why it works: Incremental phases, each verifiable independently.

### Example 4: Bug Fix with TDD

```
Use ralph loop to fix the date formatting bug (#142):

1. Write a failing test that reproduces the bug
2. Fix the implementation
3. Verify the fix doesn't break other tests

Completion criteria:
- New regression test exists and passes
- All existing tests still pass
- `npm run lint` clean

Max iterations: 8
```

Why it works: TDD approach, regression prevention, multiple validators.

## Bad Prompts

### Too Vague

```
❌ "Use ralph loop to make the code better"
```

No measurable completion criteria. The agent can't determine when to stop.

### No Safety Limit

```
❌ "Use ralph loop to build the entire app"
```

Scope too large, no iteration limit, no phases.

### Impossible Criteria

```
❌ "Use ralph loop until there are zero warnings in the entire codebase"
```

Pre-existing warnings may be out of scope. Set achievable goals.

## Prompt Patterns

### Pattern: Validate-Fix-Repeat

```
Run {validation command}.
For each failure:
  - Identify root cause
  - Apply minimal fix
  - Re-run validation
Complete when: {validation command} succeeds
```

### Pattern: Incremental Build

```
Phase 1: {smallest working piece} → validate
Phase 2: {add next feature} → validate
Phase N: {final feature} → validate
Complete when: all phases done and validated
```

### Pattern: Converging Fix

```
Start: Run full test suite
Each iteration: Fix the MOST COMMON failure pattern first
Complete when: All tests pass
Escape: After 3 iterations with same failure count, try alternative approach
```
