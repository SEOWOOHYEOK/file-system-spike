---
name: react-best-practices
description: React and Next.js performance optimization guidelines from Vercel Engineering. Apply when writing, reviewing, or refactoring React/Next.js code. Triggers on tasks involving React components, Next.js pages, data fetching, bundle optimization, re-renders, or performance improvements.
---

# React Best Practices

Comprehensive performance optimization guide for React and Next.js applications from Vercel Engineering. Contains 57 rules across 8 categories, prioritized by impact.

## When to Apply

Reference these guidelines when:
- Writing new React components or Next.js pages
- Implementing data fetching (client or server-side)
- Reviewing code for performance issues
- Refactoring existing React/Next.js code
- Optimizing bundle size or load times

## Rule Categories by Priority

| Priority | Category | Impact | Prefix |
|----------|----------|--------|--------|
| 1 | Eliminating Waterfalls | CRITICAL | `async-` |
| 2 | Bundle Size Optimization | CRITICAL | `bundle-` |
| 3 | Server-Side Performance | HIGH | `server-` |
| 4 | Client-Side Data Fetching | MEDIUM-HIGH | `client-` |
| 5 | Re-render Optimization | MEDIUM | `rerender-` |
| 6 | Rendering Performance | MEDIUM | `rendering-` |
| 7 | JavaScript Performance | LOW-MEDIUM | `js-` |
| 8 | Advanced Patterns | LOW | `advanced-` |

## Quick Reference

### 1. Eliminating Waterfalls (CRITICAL)

```typescript
// BAD: Sequential execution
const user = await fetchUser()
const posts = await fetchPosts()

// GOOD: Parallel execution
const [user, posts] = await Promise.all([fetchUser(), fetchPosts()])
```

**Key rules:**
- `async-defer-await` - Move await into branches where actually used
- `async-parallel` - Use Promise.all() for independent operations
- `async-suspense-boundaries` - Use Suspense to stream content

### 2. Bundle Size Optimization (CRITICAL)

```typescript
// BAD: Imports entire library
import { Check, X } from 'lucide-react'

// GOOD: Direct imports
import Check from 'lucide-react/dist/esm/icons/check'

// GOOD: With Next.js optimizePackageImports
// next.config.js: experimental: { optimizePackageImports: ['lucide-react'] }
```

**Key rules:**
- `bundle-barrel-imports` - Import directly, avoid barrel files
- `bundle-dynamic-imports` - Use next/dynamic for heavy components
- `bundle-defer-third-party` - Load analytics after hydration

### 3. Server-Side Performance (HIGH)

```typescript
// BAD: No auth check
'use server'
export async function deleteUser(id: string) {
  await db.user.delete({ where: { id } })
}

// GOOD: Always verify auth inside action
'use server'
export async function deleteUser(id: string) {
  const session = await verifySession()
  if (!session) throw unauthorized()
  await db.user.delete({ where: { id } })
}
```

**Key rules:**
- `server-auth-actions` - Authenticate Server Actions like API routes
- `server-cache-react` - Use React.cache() for per-request deduplication
- `server-serialization` - Minimize data passed to client components

### 4. Client-Side Data Fetching (MEDIUM-HIGH)

```typescript
// BAD: Each instance fetches
useEffect(() => { fetch('/api/users').then(setUsers) }, [])

// GOOD: Automatic deduplication with SWR
const { data: users } = useSWR('/api/users', fetcher)
```

**Key rules:**
- `client-swr-dedup` - Use SWR for automatic request deduplication
- `client-passive-event-listeners` - Use passive listeners for scroll

### 5. Re-render Optimization (MEDIUM)

```typescript
// BAD: Callback recreated on every items change
const addItem = useCallback((item) => {
  setItems([...items, item])
}, [items])

// GOOD: Functional setState - stable callback
const addItem = useCallback((item) => {
  setItems(curr => [...curr, item])
}, [])
```

**Key rules:**
- `rerender-functional-setstate` - Use functional setState for stable callbacks
- `rerender-lazy-state-init` - Pass function to useState for expensive values
- `rerender-derived-state-no-effect` - Derive state during render, not effects
- `rerender-memo` - Extract expensive work into memoized components

### 6. Rendering Performance (MEDIUM)

```typescript
// BAD: Renders "0" when count is 0
{count && <Badge>{count}</Badge>}

// GOOD: Explicit conditional
{count > 0 ? <Badge>{count}</Badge> : null}
```

**Key rules:**
- `rendering-conditional-render` - Use ternary, not && for conditionals
- `rendering-content-visibility` - Use CSS content-visibility for long lists
- `rendering-hydration-no-flicker` - Use inline script for client-only data

### 7. JavaScript Performance (LOW-MEDIUM)

```typescript
// BAD: O(n) per lookup
users.find(u => u.id === order.userId)

// GOOD: O(1) with Map
const userById = new Map(users.map(u => [u.id, u]))
userById.get(order.userId)
```

**Key rules:**
- `js-index-maps` - Build Map for repeated lookups
- `js-set-map-lookups` - Use Set/Map for O(1) lookups
- `js-tosorted-immutable` - Use toSorted() for immutability

### 8. Advanced Patterns (LOW)

```typescript
// BAD: Runs twice in dev, re-runs on remount
useEffect(() => { initializeApp() }, [])

// GOOD: Module-level guard
let didInit = false
useEffect(() => {
  if (didInit) return
  didInit = true
  initializeApp()
}, [])
```

**Key rules:**
- `advanced-init-once` - Initialize app once per app load
- `advanced-use-latest` - useLatest for stable callback refs

## Common Patterns Summary

### Async Data Fetching
1. Use `Promise.all()` for independent operations
2. Use `better-all` for partial dependencies
3. Start promises early, await late in API routes

### Bundle Optimization
1. Direct imports over barrel files
2. `next/dynamic` with `ssr: false` for heavy components
3. Preload on hover/focus for perceived speed

### Server Components
1. Always auth check inside Server Actions
2. Use `React.cache()` for deduplication
3. Minimize serialization at RSC boundaries

### Re-render Prevention
1. Functional setState updates
2. Lazy state initialization
3. Primitive dependencies in effects
4. Extract memoized components

## Additional Resources

For complete rule details with full code examples, see [RULES.md](RULES.md)

## References

- https://react.dev
- https://nextjs.org
- https://swr.vercel.app
- https://vercel.com/blog/how-we-optimized-package-imports-in-next-js
