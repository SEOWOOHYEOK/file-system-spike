# 실제 코드 예시

## Context 서비스 예시 (auth-context)

```typescript
// auth-context/auth.service.ts
import { Injectable } from '@nestjs/common';
import { VerifyAndSyncUserHandler } from './handlers/verify-and-sync-user.handler';
import { GetUserWithRolesHandler } from './handlers/get-user-with-roles.handler';
import { LoginHandler } from './handlers/login.handler';
import {
  VerifyAndSyncUserCommand,
  VerifyAndSyncUserResult,
  GetUserWithRolesQuery,
  GetUserWithRolesResult,
  LoginCommand,
  LoginResult,
} from './interfaces/auth-context.interface';

@Injectable()
export class AuthService {
  constructor(
    private readonly verifyAndSyncUserHandler: VerifyAndSyncUserHandler,
    private readonly getUserWithRolesHandler: GetUserWithRolesHandler,
    private readonly loginHandler: LoginHandler,
  ) {}

  async 토큰검증및사용자조회(accessToken: string): Promise<VerifyAndSyncUserResult> {
    const command: VerifyAndSyncUserCommand = { accessToken };
    return this.verifyAndSyncUserHandler.execute(command);
  }

  async 역할포함사용자조회(employeeNumber: string): Promise<GetUserWithRolesResult> {
    const query: GetUserWithRolesQuery = { employeeNumber };
    return this.getUserWithRolesHandler.execute(query);
  }

  async 로그인한다(email: string, password: string): Promise<LoginResult> {
    const command: LoginCommand = { email, password };
    return this.loginHandler.execute(command);
  }
}
```

## Handler 예시 (login.handler.ts)

```typescript
import {
  Injectable,
  Logger,
  UnauthorizedException,
  InternalServerErrorException,
} from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { SSOService } from '@domain/common/sso';
import type { ISSOService } from '@domain/common/sso/interfaces';
import { EmployeeService } from '@domain/common/employee/employee.service';
import {
  LoginCommand,
  LoginResult,
  AuthenticatedUserInfo,
} from '../interfaces/auth-context.interface';

@Injectable()
export class LoginHandler {
  private readonly logger = new Logger(LoginHandler.name);

  constructor(
    @Inject(SSOService) private readonly ssoService: ISSOService,
    private readonly employeeService: EmployeeService,
  ) {}

  async execute(command: LoginCommand): Promise<LoginResult> {
    const { email, password } = command;
    this.logger.log(`로그인 시도: ${email}`);

    // 1. SSO 로그인
    let loginResult;
    try {
      loginResult = await this.ssoService.로그인한다(email, password);
    } catch (error) {
      const errorMessage = error?.message || '로그인 처리 중 오류가 발생했습니다.';
      throw new UnauthorizedException(errorMessage);
    }

    // 2. Employee 조회
    const employee = await this.employeeService.findByEmployeeNumber(
      loginResult.employeeNumber,
    );

    if (!employee) {
      // SSO 정보만 사용하여 기본 사용자 정보 생성
      const roles: string[] = loginResult.systemRoles?.['EMS-PROD'] || [];
      const userInfo: AuthenticatedUserInfo = {
        id: '',
        externalId: loginResult.id || '',
        email: loginResult.email,
        name: loginResult.name,
        employeeNumber: loginResult.employeeNumber,
        roles: roles,
        status: 'ACTIVE',
      };

      return {
        user: userInfo,
        accessToken: loginResult.accessToken,
        refreshToken: loginResult.refreshToken,
      };
    }

    // 3. 역할 정보 추출 및 업데이트
    const roles: string[] = loginResult.systemRoles?.['EMS-PROD'] || [];
    await this.employeeService.updateRoles(employee.id, roles);

    // 4. 결과 반환
    const userInfo: AuthenticatedUserInfo = {
      id: employee.id,
      externalId: employee.externalId,
      email: employee.email,
      name: employee.name,
      employeeNumber: employee.employeeNumber,
      roles: roles,
      status: employee.status,
    };

    return {
      user: userInfo,
      accessToken: loginResult.accessToken,
      refreshToken: loginResult.refreshToken,
    };
  }
}
```

## Interface 예시

```typescript
// interfaces/auth-context.interface.ts

export interface AuthenticatedUserInfo {
  id: string;
  externalId: string;
  email: string;
  name: string;
  employeeNumber: string;
  roles: string[];
  status: string;
}

export interface VerifyAndSyncUserCommand {
  accessToken: string;
}

export interface VerifyAndSyncUserResult {
  user: AuthenticatedUserInfo;
  isSynced: boolean;
}

export interface GetUserWithRolesQuery {
  employeeNumber: string;
}

export interface GetUserWithRolesResult {
  user: AuthenticatedUserInfo | null;
}

export interface LoginCommand {
  email: string;
  password: string;
}

export interface LoginResult {
  user: AuthenticatedUserInfo;
  accessToken: string;
  refreshToken: string;
}
```

## Handler Index 예시

```typescript
// handlers/project-assignment/index.ts

// Commands
export {
  CreateProjectAssignmentCommand,
  CreateProjectAssignmentHandler,
} from './commands/create-project-assignment.handler';

export {
  CancelProjectAssignmentCommand,
  CancelProjectAssignmentHandler,
} from './commands/cancel-project-assignment.handler';

export {
  BulkCreateProjectAssignmentCommand,
  BulkCreateProjectAssignmentHandler,
} from './commands/bulk-create-project-assignment.handler';

// Queries
export {
  GetProjectAssignmentListQuery,
  GetProjectAssignmentListHandler,
  type ProjectAssignmentListResult,
} from './queries/get-project-assignment-list.handler';

export {
  GetEmployeeProjectAssignmentsQuery,
  GetEmployeeProjectAssignmentsHandler,
} from './queries/get-employee-project-assignments.handler';

// Handler 배열
import { CreateProjectAssignmentHandler } from './commands/create-project-assignment.handler';
import { CancelProjectAssignmentHandler } from './commands/cancel-project-assignment.handler';
import { BulkCreateProjectAssignmentHandler } from './commands/bulk-create-project-assignment.handler';
import { GetProjectAssignmentListHandler } from './queries/get-project-assignment-list.handler';
import { GetEmployeeProjectAssignmentsHandler } from './queries/get-employee-project-assignments.handler';

export const PROJECT_ASSIGNMENT_COMMAND_HANDLERS = [
  CreateProjectAssignmentHandler,
  CancelProjectAssignmentHandler,
  BulkCreateProjectAssignmentHandler,
];

export const PROJECT_ASSIGNMENT_QUERY_HANDLERS = [
  GetProjectAssignmentListHandler,
  GetEmployeeProjectAssignmentsHandler,
];

export const PROJECT_ASSIGNMENT_HANDLERS = [
  ...PROJECT_ASSIGNMENT_COMMAND_HANDLERS,
  ...PROJECT_ASSIGNMENT_QUERY_HANDLERS,
];
```

## Business Service 예시

```typescript
// evaluation-line-business.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { EvaluationCriteriaManagementService } from '@context/evaluation-criteria-management-context/evaluation-criteria-management.service';
import { EvaluationActivityLogContextService } from '@context/evaluation-activity-log-context/evaluation-activity-log-context.service';

@Injectable()
export class EvaluationLineBusinessService {
  private readonly logger = new Logger(EvaluationLineBusinessService.name);

  constructor(
    private readonly evaluationCriteriaManagementService: EvaluationCriteriaManagementService,
    private readonly activityLogContextService: EvaluationActivityLogContextService,
  ) {}

  async 일차_평가자를_구성한다(
    employeeId: string,
    periodId: string,
    evaluatorId: string,
    createdBy: string,
  ): Promise<{
    message: string;
    createdLines: number;
    createdMappings: number;
    mapping: {
      id: string;
      employeeId: string;
      evaluatorId: string;
      wbsItemId: string | null;
      evaluationLineId: string;
    };
  }> {
    this.logger.log('1차 평가자 구성 시작', { employeeId, periodId, evaluatorId });

    // 1차 평가자 구성 (Context Service 호출)
    const result =
      await this.evaluationCriteriaManagementService.일차_평가자를_구성한다(
        employeeId,
        periodId,
        evaluatorId,
        createdBy,
      );

    // 활동 내역 기록
    try {
      await this.activityLogContextService.활동내역을_기록한다({
        periodId,
        employeeId,
        activityType: 'evaluation_line',
        activityAction: 'updated',
        activityTitle: '1차 평가자 구성',
        relatedEntityType: 'evaluation_line_mapping',
        relatedEntityId: result.mapping.id,
        performedBy: createdBy,
        activityMetadata: {
          evaluatorId,
          evaluatorType: 'primary',
        },
      });
    } catch (error) {
      // 활동 내역 기록 실패 시에도 평가라인 구성은 정상 처리
      this.logger.warn('1차 평가자 구성 활동 내역 기록 실패', {
        employeeId,
        periodId,
        evaluatorId,
        error: error.message,
      });
    }

    this.logger.log('1차 평가자 구성 완료', {
      employeeId,
      evaluatorId,
      mappingId: result.mapping.id,
    });

    return result;
  }
}
```

## 복잡한 QueryBuilder 예시

```typescript
private async getProjectsWithWbs(
  evaluationPeriodId: string,
  employeeId: string,
): Promise<AssignedProjectWithWbs[]> {
  // 1. 프로젝트 할당 조회
  const projectAssignments = await this.projectAssignmentRepository
    .createQueryBuilder('assignment')
    .select([
      'assignment.id AS assignment_id',
      'assignment.projectId AS assignment_projectId',
      'assignment.createdAt AS assignment_createdAt',
      'project.id AS project_id',
      'project.name AS project_name',
      'project.code AS project_code',
    ])
    .leftJoin(
      Project,
      'project',
      'project.id = assignment.projectId AND project.deletedAt IS NULL',
    )
    .where('assignment.evaluationPeriodId = :evaluationPeriodId', {
      evaluationPeriodId,
    })
    .andWhere('assignment.employeeId = :employeeId', { employeeId })
    .andWhere('assignment.deletedAt IS NULL')
    .orderBy('assignment.createdAt', 'ASC')
    .getRawMany();

  // 2. 각 프로젝트의 WBS 조회
  const result: AssignedProjectWithWbs[] = [];
  for (const pa of projectAssignments) {
    const wbsList = await this.getWbsListByProject(
      evaluationPeriodId,
      employeeId,
      pa.project_id,
    );

    result.push({
      projectId: pa.project_id,
      projectName: pa.project_name,
      projectCode: pa.project_code,
      assignedAt: pa.assignment_createdAt,
      wbsList,
    });
  }

  return result;
}
```

## 디렉토리 구조 예시

```
src/context/evaluation-criteria-management-context/
├── evaluation-criteria-management-context.module.ts
├── evaluation-criteria-management.service.ts
├── handlers/
│   ├── evaluation-line/
│   │   ├── commands/
│   │   │   ├── configure-primary-evaluator.handler.ts
│   │   │   ├── configure-secondary-evaluator.handler.ts
│   │   │   └── auto-configure-primary-evaluator-by-manager-for-all-employees.handler.ts
│   │   ├── queries/
│   │   │   ├── get-employee-evaluation-line-mappings.handler.ts
│   │   │   ├── get-evaluation-line-list.handler.ts
│   │   │   └── get-evaluator-employees.handler.ts
│   │   └── index.ts
│   ├── project-assignment/
│   │   ├── commands/
│   │   │   ├── create-project-assignment.handler.ts
│   │   │   ├── cancel-project-assignment.handler.ts
│   │   │   └── bulk-create-project-assignment.handler.ts
│   │   ├── queries/
│   │   │   ├── get-project-assignment-list.handler.ts
│   │   │   ├── get-employee-project-assignments.handler.ts
│   │   │   └── get-available-projects.handler.ts
│   │   └── index.ts
│   └── wbs-assignment/
│       ├── commands/
│       ├── queries/
│       └── index.ts
├── interfaces/
│   ├── evaluation-criteria-management.interface.ts
│   └── project-assignment-cqrs.interface.ts
└── services/
    ├── wbs-assignment-validation.service.ts
    └── wbs-assignment-weight-calculation.service.ts
```

## Business 디렉토리 구조 예시

```
src/business/
├── business.module.ts
├── evaluation-line/
│   ├── evaluation-line-business.module.ts
│   └── evaluation-line-business.service.ts
├── peer-evaluation/
│   ├── peer-evaluation-business.module.ts
│   └── peer-evaluation-business.service.ts
├── project-assignment/
│   ├── project-assignment-business.module.ts
│   └── project-assignment-business.service.ts
└── wbs-assignment/
    ├── wbs-assignment-business.module.ts
    └── wbs-assignment-business.service.ts
```
